const peopleData = require('./userApi');
const workData = require('./userApi');

// not much to do here
module.exports = {
  people: peopleData,
  work: workData
};
