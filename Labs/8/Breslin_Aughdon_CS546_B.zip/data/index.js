
module.exports = {
  searchShow: require('./searchshows'),
  show: require('./shows')
};