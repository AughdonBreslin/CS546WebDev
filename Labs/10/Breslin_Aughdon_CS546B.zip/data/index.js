const userData = require('./users');

// not much to do here
module.exports = {
  users: userData
};