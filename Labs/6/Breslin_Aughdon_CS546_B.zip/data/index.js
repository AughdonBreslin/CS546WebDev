const albumsData = require('./albums');
const bandsData = require('./bands');

// not much to do here
module.exports = {
  albums: albumsData,
  bands: bandsData
};